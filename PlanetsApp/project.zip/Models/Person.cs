﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlanetsApp.Models
{
    // simple model for person
    // only storing data points required for app, more can be added
    public class Person
    {
        public required string Name { get; set; }
    }
}
